# LibreTransmitter for Loop
This was a https://github.com/loopkit/loop plugin for connecting to libresensors via miaomiao and bubble transmitters, as well as directly when the sensor supported it (libre2 eu).

This repository is now being retired and archived, as it has been upstreamed. See https://github.com/LoopKit/LibreTransmitter/ for further development

